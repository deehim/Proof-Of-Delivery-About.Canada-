//
//  ListTableVC.h
//  ProofOfConcept
//
//  Created by Apple on 21/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListTableVC : UITableViewController

@end
